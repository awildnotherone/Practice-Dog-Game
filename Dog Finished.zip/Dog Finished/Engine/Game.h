/****************************************************************************************** 
 *	Chili DirectX Framework Version 16.07.20											  *	
 *	Game.h																				  *
 *	Copyright 2016 PlanetChili.net <http://www.planetchili.net>							  *
 *																						  *
 *	This file is part of The Chili DirectX Framework.									  *
 *																						  *
 *	The Chili DirectX Framework is free software: you can redistribute it and/or modify	  *
 *	it under the terms of the GNU General Public License as published by				  *
 *	the Free Software Foundation, either version 3 of the License, or					  *
 *	(at your option) any later version.													  *
 *																						  *
 *	The Chili DirectX Framework is distributed in the hope that it will be useful,		  *
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of						  *
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the						  *
 *	GNU General Public License for more details.										  *
 *																						  *
 *	You should have received a copy of the GNU General Public License					  *
 *	along with The Chili DirectX Framework.  If not, see <http://www.gnu.org/licenses/>.  *
 ******************************************************************************************/
#pragma once

#include "Keyboard.h"
#include "Mouse.h"
#include "Graphics.h"

class Game
{
public:
	Game( class MainWindow& wnd );
	Game( const Game& ) = delete;
	Game& operator=( const Game& ) = delete;
	void Go();
private:
	void ComposeFrame();
	void UpdateModel();
	/********************************/
	/*  User Functions              */
	void DrawTitleScreen(int sx, int sy); 
	void DrawBone(int tx, int ty);
	void DrawDogForward(int fx, int fy);
	void DrawDogBackward(int bx, int by);
	void DrawGameOver(int ox, int oy); 

	bool IsCollidingForward(int fx, int fy, int fWidth, int fHeight,
		int tx, int ty, int tWidth, int tHeight);
	bool IsCollidingBackward(int bx, int by, int bWidth, int bHeight,
		int tx, int ty, int tWidth, int tHeight);
	bool OverlapTest(int fx, int fy, int tx, int ty);
	/********************************/
private:
	MainWindow& wnd;
	Graphics gfx;
	/********************************/
	/*  User Variables              */
	bool GameisStarted = false; 

	int fx = 400;
	int fy = 300;
	int fWidth = 17;
	int fHeight = 16;

	int bx = 400;
	int by = 300;
	int bWidth = 17;
	int bHeight;

	int tx = 100;
	int ty = 100;
	int tWidth = 12;
	int tHeight = 7;
	bool t0isEaten = false;

	int t1x = 200;
	int t1y = 200;
	int t1Width = 12;
	int t1Height = 7;
	bool t1isEaten = false;

	int t2x = 300;
	int t2y = 500;
	int t2Width = 12;
	int t2Height = 7;
	bool t2isEaten = false;

	int t3x = 700;
	int t3y = 100;
	int t3Width = 12;
	int t3Height = 7;
	bool t3isEaten = false;

	int t4x = 600;
	int t4y = 500;
	int t4Width = 12;
	int t4Height = 7;
	bool t4isEaten = false;

	int vfx = 0;
	int vfy = 0;
	int vbx = 0;
	int vby = 0;

	bool left = false;
	bool colliding0 = false; 
	bool colliding1 = false; 
	bool colliding2 = false; 
	bool colliding3 = false; 
	bool colliding4 = false;

	bool inhibitUp = false;
	bool inhibitDown = false;
	bool inhibitLeft = false;
	bool inhibitRight = false;
	/********************************/
};